package nl.bravobit.ffmpeg;

public interface ResponseHandler {

    /**
     * on Start
     */
    void onStart();

    /**
     * on Finish
     */
    void onFinish();

}
